﻿using Microsoft.EntityFrameworkCore;
using ASPNETMVCCURD.Models.Domain; // as we created the employee in the domain in model

namespace ASPNETMVCCURD.Data
{
    public class MVCDemoDbContext : DbContext
    {
        public MVCDemoDbContext(DbContextOptions options) : base(options)
        {

        }

        public DbSet<Employee> Employees { get; set; } //To Access the table that entity framework core will create in our database and Employees will be the taable name we created

    }
}
