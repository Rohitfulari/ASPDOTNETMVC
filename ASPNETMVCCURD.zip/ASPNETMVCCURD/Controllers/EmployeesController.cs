﻿using ASPNETMVCCURD.Data;
using ASPNETMVCCURD.Models;
using ASPNETMVCCURD.Models.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace ASPNETMVCCURD.Controllers
{
    public class EmployeesController : Controller
    {
        private readonly MVCDemoDbContext mvcDemoDbContext;

        public EmployeesController(MVCDemoDbContext mvcDemoDbContext)
        {
            this.mvcDemoDbContext = mvcDemoDbContext;
        }


        [HttpGet]
        public async Task<IActionResult> Index1()
        {
            var employees = await mvcDemoDbContext.Employees.ToListAsync();
            return View(employees);
        }




        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }




        [HttpPost]
        public async Task<IActionResult>  Add(AddEmployeeViewModel addEmployeeRequest)
        {
            var employee = new Employee()
            {
                Id = Guid.NewGuid(),
                Name = addEmployeeRequest.Name,
                Email = addEmployeeRequest.Email,
                Salary = addEmployeeRequest.Salary,
                Department = addEmployeeRequest.Department,
                DateOfBirth = addEmployeeRequest.DateOfBirth
            };

            await mvcDemoDbContext.Employees.AddAsync(employee);
            await mvcDemoDbContext.SaveChangesAsync();
            return RedirectToAction("Index1"); // by this after we hit the submit button we go bacck to index page i.e all the details of employee added
        }






        [HttpGet]
        public  async Task<IActionResult> View(Guid id)
        {
            // Retrieve the employee details based on the provided Id
            var employee =  await mvcDemoDbContext.Employees.FirstOrDefaultAsync(e => e.Id == id);

            if (employee != null)
            {
                var viewModel = new UpdateEmployeeViewModel()
                {
                    Id = employee.Id,
                    Name = employee.Name,
                    Email = employee.Email,
                    Salary = employee.Salary,
                    Department = employee.Department,
                    DateOfBirth = employee.DateOfBirth

                };

                return await Task.Run(() => View("View",viewModel)); 

            }

           


          
            return RedirectToAction("Index1");
        }


        [HttpPost]
        public async Task<IActionResult> View(UpdateEmployeeViewModel model)
        {
            var employee = await mvcDemoDbContext.Employees.FindAsync(model.Id);

            if (employee != null) 
            {
                employee.Name = model.Name;
                employee.Email = model.Email;   
                employee.Salary = model.Salary;
                employee.Department = model.Department;
                 employee.DateOfBirth = model.DateOfBirth;

                await mvcDemoDbContext.SaveChangesAsync();

                return RedirectToAction("Index1");
            }

            return RedirectToAction("Index1");
        }



           

            

        }
    }


